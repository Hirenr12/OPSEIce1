package com.example.splashscreen

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class Korean : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_korean)
        // Find the backButton by id
        val backButton = findViewById<Button>(R.id.buttonKorean)

        // Set click listener on the backButton
        backButton.setOnClickListener{
            // Create an Intent to go back to the HomeScreen activity
            val intent = Intent(this, HomeScreen::class.java)
            // Start the activity using the Intent
            startActivity(intent)
            // Finish this activity (optional)
            finish()
        }
    }

}