package com.example.splashscreen

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast

class HomeScreenItalian : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home_screen_italian)

        // Find the backButton by id
        val backButton = findViewById<Button>(R.id.backButton)

        // Set click listener on the backButton
        backButton.setOnClickListener{
            // Create an Intent to go back to the HomeScreen activity
            val intent = Intent(this, HomeScreen::class.java)
            // Start the activity using the Intent
            startActivity(intent)
            // Finish this activity (optional)
            finish()
        }
    }
    private fun clickItalian(){
        Toast.makeText(this,"Button Click",Toast.LENGTH_SHORT).show()

        val intent=Intent(this,HomeScreen::class.java)
        startActivity(intent)
    }
    private fun clickJapanese(){
        Toast.makeText(this,"Button Click",Toast.LENGTH_SHORT).show()

        val intent=Intent(this,HomeScreen::class.java)
        startActivity(intent)
    }
    private fun clickKorean(){
        Toast.makeText(this,"Button Click",Toast.LENGTH_SHORT).show()

        val intent=Intent(this,HomeScreen::class.java)
        startActivity(intent)
    }
    private fun clickEnglish(){
        Toast.makeText(this,"Button Click",Toast.LENGTH_SHORT).show()

        val intent=Intent(this,HomeScreen::class.java)
        startActivity(intent)
    }

}
