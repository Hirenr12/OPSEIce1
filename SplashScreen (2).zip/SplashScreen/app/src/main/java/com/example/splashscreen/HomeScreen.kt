package com.example.splashscreen

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class HomeScreen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home_screen)

        // Find the button by id
        val pizzaButton = findViewById<Button>(R.id.button)

        // Set click listener on the button
        pizzaButton.setOnClickListener{
            // Create an Intent to launch HomeScreenItalian
            val intent = Intent(this, HomeScreenItalian::class.java)
            // Start the activity using the Intent
            startActivity(intent)
        }

        // Find the button by id
        val buttonJapanese = findViewById<Button>(R.id.buttonJapanese)

        // Set click listener on the button
        buttonJapanese.setOnClickListener{
            // Create an Intent to launch HomeScreenItalian
            val intent = Intent(this, Japanese::class.java)
            // Start the activity using the Intent
            startActivity(intent)
        }

        // Find the button by id
        val buttonKorean = findViewById<Button>(R.id.buttonKorean)

        // Set click listener on the button
        buttonKorean.setOnClickListener{
            // Create an Intent to launch HomeScreenItalian
            val intent = Intent(this, Korean::class.java)
            // Start the activity using the Intent
            startActivity(intent)
        }
    }
}
