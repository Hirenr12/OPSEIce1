package com.example.splashscreen

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast

class Japanese : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_japanese)

        // Find the backButton by id
        val backButton = findViewById<Button>(R.id.buttonJapanese)

        // Set click listener on the backButton
        backButton.setOnClickListener{
            // Create an Intent to go back to the HomeScreen activity
            val intent = Intent(this, HomeScreen::class.java)
            // Start the activity using the Intent
            startActivity(intent)
            // Finish this activity (optional)
            finish()
        }
    }

}